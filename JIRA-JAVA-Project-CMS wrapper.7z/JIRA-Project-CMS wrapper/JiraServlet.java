package it.ltm.tool.cmswrapper.jira.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import it.ltm.cmswrapper.persistence.client.service.GNSCMSDBService;
import it.ltm.tool.cmswrapper.enums.ConfigurationEnum;
import it.ltm.tool.cmswrapper.enums.EmailStatus;
import it.ltm.tool.cmswrapper.enums.GovToolConfEnum;
import it.ltm.tool.cmswrapper.enums.Module;
import it.ltm.tool.cmswrapper.gov.tool.bean.ChannelJSON;
import it.ltm.tool.cmswrapper.gov.tool.bean.GameCodeBean;
import it.ltm.tool.cmswrapper.gov.tool.bean.GroupChannelJSON;
import it.ltm.tool.cmswrapper.gov.tool.logic.InsertGameCodeLogic;
import it.ltm.tool.cmswrapper.gov.tool.ui.util.Utils;
import it.ltm.tool.cmswrapper.jira.scheduler.client.MyJiraClientInterface;
import it.ltm.tool.cmswrapper.jira.scheduler.client.TaskConfiguration;
import it.ltm.tool.cmswrapper.singleton.ConfigurationSingleton;
import it.ltm.tool.cmswrapper.singleton.GovToolConfSingleton;
import it.ltm.tool.cmswrapper.util.ClientUtility;

public class JiraServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(JiraServlet.class);
	
	private static final Module MODULE = Module.DEFAULT;

	private GNSCMSDBService cmsDBService;

	private MyJiraClientInterface myJiraClient;

	@Override
	public void init(ServletConfig config) throws ServletException {
		log.debug("CMSWrapper - GameConfigurationServlet - INIT - START");
		this.cmsDBService = ClientUtility.doLocalLookup(this.cmsDBService, GNSCMSDBService.JNDI);
		this.myJiraClient = ClientUtility.doLocalLookup(this.myJiraClient, MyJiraClientInterface.JNDI);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		log.info("#########################################################################");
		log.info("###############            AUTOMATIC GAME CONFIGURATION           ##############");
		log.info("#########################################################################");

		String sso = req.getParameter("sso");
		
		if (!"admin".equalsIgnoreCase(sso)) {
			log.info("Not permitted");
			resp.getOutputStream().println("Not permitted");
			return;
		}

		if(Boolean.parseBoolean(ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_AUTOMATION_PROCESS))) {

			String username = ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_USERNAME);
			String password = ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_PASSWORD_CRIPTED);
			String jiraUrl = ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_URL);
			String jiraJql = ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_JQL);

			List<TaskConfiguration> issues = this.myJiraClient.searchJql(username, password, jiraUrl, jiraJql);
			resp.getOutputStream().println("Issue Trovate : " + issues.size());
			log.info("Issue Trovate : " + issues.size());

			boolean result = Boolean.FALSE;
			for (TaskConfiguration taskConfiguration : issues) {

				log.info("JiraServlet - doGet [ " + taskConfiguration + "]");

				resp.getOutputStream().println("Working Issue : " + taskConfiguration.getJiraLink());

				if (taskConfiguration.getGamePlatform()
						.equalsIgnoreCase(ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.NETENT))) {
					taskConfiguration.setGamePlatform(ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.NETENT_NEW));
				}
				
				if (taskConfiguration.getGamePlatform()
						.equalsIgnoreCase(ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.IGT))) {
					taskConfiguration.setGamePlatform(ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.IGT_NEW));
				}
				
				log.info("JiraServlet - doGet [ " + taskConfiguration + "]");

				Long platformId = this.cmsDBService.getPlatformIdFromKeyAndProviderName(taskConfiguration.getGamePlatform());

				log.info("JiraServlet - doGet - Platform della issue " + platformId);
				if (platformId.equals(0L)) {
					resp.getOutputStream().println("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
							+ taskConfiguration.getAamsCode() + ". Result " + result + ". GamePlatform not found.");
					log.info("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
							+ taskConfiguration.getAamsCode() + ". Result " + result + ". GamePlatform not found.");
					continue;
				}

				if (!taskConfiguration.getProvidergamecode_ALL().isEmpty()) {
					List<GroupChannelJSON> channelCategoryList = Utils.getGroupChannelList(platformId);

					result = this.prepareRequest(platformId, taskConfiguration, channelCategoryList, taskConfiguration.getProvidergamecode_ALL());

					resp.getOutputStream().println("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
							+ taskConfiguration.getAamsCode() + " for the channel " + channelCategoryList + ". Result " + result);
					log.info("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
							+ taskConfiguration.getAamsCode() + " for the channel " + channelCategoryList + ". Result " + result);
				} else {

					if (!taskConfiguration.getProvidergamecode_WEB().isEmpty()) {
						result = this.prepareRequest(platformId, taskConfiguration, "WEB", taskConfiguration.getProvidergamecode_WEB());
						resp.getOutputStream().println("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel WEB. Result " + result);
						log.info("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel WEB. Result " + result);
					}

					if (!taskConfiguration.getProvidergamecode_MOBILE().isEmpty()) {
						result = this.prepareRequest(platformId, taskConfiguration, "MOBILE", taskConfiguration.getProvidergamecode_MOBILE());
						resp.getOutputStream().println("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel MOBILE. Result " + result);
						log.info("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel MOBILE. Result " + result);
					}

					if (taskConfiguration.getProvidergamecode_WEB().isEmpty() && taskConfiguration.getProvidergamecode_MOBILE().isEmpty()) {

						List<GroupChannelJSON> channelCategoryList = Utils.getGroupChannelList(platformId);

						result = this.prepareRequest(platformId, taskConfiguration, channelCategoryList, "");

						resp.getOutputStream().println("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel " + channelCategoryList + ". Result " + result);
						log.info("I worked the leanconit " + taskConfiguration.getJiraLink() + " and his game "
								+ taskConfiguration.getAamsCode() + " for the channel " + channelCategoryList + ". Result " + result);
					}
				}
				
				if(result) {
					log.info("JiraServlet - doGet - updating " + taskConfiguration.getKeyIssue());
					this.myJiraClient.updateIssueStatus(taskConfiguration.getKeyIssue(), jiraJql, ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_STATUS_ISSUE_TO_CHANGE));
				}
			}
			
		}
		else 
			resp.getOutputStream().println("Not enabled, JIRA_AUTOMATION_PROCESS is " + ConfigurationSingleton.getProperty(MODULE,ConfigurationEnum.JIRA_AUTOMATION_PROCESS));
	}

	private boolean prepareRequest(Long platformId, TaskConfiguration gameConfiguration,
			List<GroupChannelJSON> channelCategoryList, String providerGameCode) {
		boolean result = Boolean.FALSE;

		GameCodeBean gameCodeBean = new GameCodeBean();
		gameCodeBean.setGameName(gameConfiguration.getGamename());
		gameCodeBean.setAAMSCode(gameConfiguration.getAamsCode());
		gameCodeBean.setJiraLink(gameConfiguration.getJiraLink());
		gameCodeBean.setEmailStatus(EmailStatus.TO_SEND_EMAIL.getKey());

		if (!providerGameCode.isEmpty() && !(platformId.equals(70L) || platformId.equals(71L))) {
			gameCodeBean.setEmailStatus(EmailStatus.TO_FINALIZE_CONFIGURATION.getKey());
		}

		String brandsStr = GovToolConfSingleton.getProperty(platformId, GovToolConfEnum.REQUEST_BRANDS,
				StringUtils.EMPTY);
		List<String> collection = new ArrayList<String>();
		collection.add(brandsStr.split(";")[0]);
		gameCodeBean.setBrands(collection);

		gameCodeBean.setProviderGameCode(providerGameCode);

		for (GroupChannelJSON cat : channelCategoryList) {
			List<ChannelJSON> channels = Utils.getChannelList(platformId, cat.getGroupChannel());
			log.info("JiraServlet - prepareRequest - channels[ " + channels + "] per il channel [ "
					+ cat.getGroupChannel() + "]");
			gameCodeBean.setChannelGroup(cat.getGroupChannel());
			if (channels.size() > 0) {
				gameCodeBean.setChannels(channels);

				List<GameCodeBean> list = new ArrayList<GameCodeBean>();
				list.add(gameCodeBean);

				new InsertGameCodeLogic().sendRequest(platformId, list, Boolean.TRUE);
				result = Boolean.TRUE;
			}
		}

		return result;
	}

	private Boolean prepareRequest(Long platformId, TaskConfiguration gameConfiguration, String channel,
			String providerGameCode) {
		GameCodeBean gameCodeBean = new GameCodeBean();
		gameCodeBean.setGameName(gameConfiguration.getGamename());
		gameCodeBean.setAAMSCode(gameConfiguration.getAamsCode());
		gameCodeBean.setJiraLink(gameConfiguration.getJiraLink());
		gameCodeBean.setEmailStatus(EmailStatus.TO_SEND_EMAIL.getKey());

		if (!providerGameCode.isEmpty() && !(platformId.equals(70L) || platformId.equals(71L))) {
			gameCodeBean.setEmailStatus(EmailStatus.TO_FINALIZE_CONFIGURATION.getKey());
		}

		String brandsStr = GovToolConfSingleton.getProperty(platformId, GovToolConfEnum.REQUEST_BRANDS,
				StringUtils.EMPTY);
		List<String> collection = new ArrayList<String>();
		collection.add(brandsStr.split(";")[0]);
		gameCodeBean.setBrands(collection);

		gameCodeBean.setProviderGameCode(providerGameCode);
		List<ChannelJSON> channels = Utils.getChannelList(platformId, channel);
		log.info("JiraServlet - prepareRequest - channels[ " + channels + "] per il channel [ " + channel + "]");
		gameCodeBean.setChannelGroup(channel);
		if (channels.size() > 0) {
			gameCodeBean.setChannels(channels);

			List<GameCodeBean> list = new ArrayList<GameCodeBean>();
			list.add(gameCodeBean);

			new InsertGameCodeLogic().sendRequest(platformId, list, Boolean.TRUE);
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
}