package it.ltm.tool.cmswrapper.jira.scheduler.service.impl;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.jboss.ejb3.annotation.RemoteBinding;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.Transition;
import com.atlassian.jira.rest.client.api.domain.input.TransitionInput;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;

import it.ltm.tool.cmswrapper.jira.scheduler.client.MyJiraClientInterface;
import it.ltm.tool.cmswrapper.jira.scheduler.client.TaskConfiguration;

@Stateless
@RemoteBinding(jndiBinding = MyJiraClientInterface.JNDI)
public class MyJiraClient implements MyJiraClientInterface{

	private static final Logger log = Logger.getLogger(MyJiraClient.class);

	boolean startService = Boolean.TRUE;

	String username;
	String password;
	String jiraUrl;
	JiraRestClient restClient;

	public MyJiraClient() {}

	@Override
	public List<TaskConfiguration> searchJql(String username, String password, String jiraUrl, String jiraJql) {
		log.info("MyJiraClient - searchJql - jqlQuery: " + jiraJql + username+password);

		if (startService) {
			this.startService(username,password,jiraUrl);
			startService = Boolean.FALSE; 
		}

		Iterable<Issue> iterable = this.restClient.getSearchClient().searchJql(jiraJql).claim().getIssues();

		List<TaskConfiguration> taskConfigurations = new ArrayList<TaskConfiguration>();
		for (Issue issue:iterable) {
			log.info("MyJiraClient - searchJql - Issue [ " + issue.getKey() + ":" + issue.getSummary() + "]");

			ObjectMapper mapper = new ObjectMapper();
			try {
				GameConfiguration gameConfiguration = mapper.readValue(issue.getDescription(), GameConfiguration.class);

				TaskConfiguration taskConfiguration = new TaskConfiguration(gameConfiguration.getGamePlatform(),gameConfiguration.getGamename() , gameConfiguration.getAamsCode(), gameConfiguration.getEnvironment(), issue.getKey(), gameConfiguration.getProvidergamecode_ALL(), gameConfiguration.getProvidergamecode_WEB(), gameConfiguration.getProvidergamecode_MOBILE());
				taskConfiguration.setKeyIssue(issue.getKey());
				taskConfigurations.add(taskConfiguration);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			} 
		}
		return taskConfigurations;
	}

	@Override
	public void updateIssueStatus(String keyIssue, String jiraJql, String status) {

		log.info("MyJiraClient - updateIssueStatus - Issue [ " + keyIssue + ", JiraJql" + jiraJql + "]");
		jiraJql.concat(" AND key = " + keyIssue );
		Iterable<Issue> iterable = this.restClient.getSearchClient().searchJql(jiraJql).claim().getIssues();

		for (Issue issue:iterable) {
			Iterable<Transition> transitions = this.restClient.getIssueClient().getTransitions(issue).claim();

			for(Transition t : transitions){
				if(t.getName().equals(status)) {
					log.info("MyJiraClient - updateIssueStatus - key " + issue.getKey() + " - stato da aggiornare " + status);
					System.out.println("MyJiraClient - updateIssueStatus - key " + issue.getKey() + " - stato da aggiornare " + status);
					TransitionInput input = new TransitionInput(t.getId());
					this.restClient.getIssueClient().transition(issue, input).claim();           
					return;
				}
			}
		}
	}

	private void startService(String username, String password, String jiraUrl) {
		this.username = username;
		this.password = new String(DatatypeConverter.parseBase64Binary(password));
		this.jiraUrl = jiraUrl;
		this.restClient = getJiraRestClient();
	}

	private JiraRestClient getJiraRestClient() {
		return new AsynchronousJiraRestClientFactory()
				.createWithBasicHttpAuthentication(getJiraUri(), this.username, this.password);
	}

	private URI getJiraUri() {
		return URI.create(this.jiraUrl);
	}

	@Override
	public String toString() {
		return "MyJiraClient [username=" + username + ", password=" + password + ", jiraUrl=" + jiraUrl
				+ ", restClient=" + restClient + "]";
	}
}